/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QFrame *frame;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QFrame *frame_4;
    QPushButton *pushButton_31;
    QFrame *frame_7;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QPushButton *pushButton_34;
    QLabel *label_12;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QPushButton *pushButton_38;
    QPushButton *pushButton_39;
    QPushButton *pushButton_40;
    QPushButton *pushButton_41;
    QPushButton *pushButton_42;
    QPushButton *pushButton_43;
    QFrame *frame_8;
    QFrame *frame_6;
    QLabel *label_11;
    QPushButton *pushButton_28;
    QPushButton *pushButton_29;
    QFrame *frame_5;
    QLabel *label_10;
    QPushButton *pushButton_14;
    QPushButton *pushButton_27;
    QFrame *frame_9;
    QPushButton *pushButton_8;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QSlider *horizontalSlider;
    QPushButton *Shuffle_btn;
    QFrame *frame_3;
    QPushButton *pushButton_6;
    QPushButton *pushButton_5;
    QSlider *horizontalSlider_2;
    QFrame *frame_2;
    QPushButton *pushButton_7;
    QLabel *current_time;
    QLabel *total_time;
    QLabel *label_13;
    QListWidget *listWidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(400, 800);
        MainWindow->setMinimumSize(QSize(400, 800));
        MainWindow->setMaximumSize(QSize(400, 800));
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(144, 175, 196);"));
        MainWindow->setAnimated(false);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(-95, -174, 303, 303));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(20);
        sizePolicy.setVerticalStretch(20);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(303, 303));
        label->setMaximumSize(QSize(303, 303));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"	background-color: rgb(95, 132, 161);\n"
"	border-radius: 151px;\n"
"}"));
        label->setFrameShape(QFrame::NoFrame);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(10, 10, 251, 91));
        QFont font;
        font.setFamilies({QString::fromUtf8("Segoe UI")});
        font.setPointSize(27);
        font.setBold(true);
        font.setItalic(false);
        font.setUnderline(false);
        font.setStrikeOut(false);
        font.setKerning(true);
        font.setStyleStrategy(QFont::PreferDefault);
        label_2->setFont(font);
        label_2->setTabletTracking(false);
        label_2->setStyleSheet(QString::fromUtf8("letter-spacing: -2px;\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"background-color: transparent;\n"
"color: #1A4568	\n"
""));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(360, 20, 28, 28));
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/gear-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton->setIconSize(QSize(100, 28));
        pushButton->setCheckable(false);
        pushButton->setAutoRepeat(false);
        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(60, 203, 281, 291));
        frame->setStyleSheet(QString::fromUtf8("background-image: url(:/Dis_pic.png);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(105, 180, 201, 22));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        label_3->setFont(font1);
        label_3->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	qproperty-alignment: 'AlignCenter';\n"
"	background-color: transparent;\n"
"	color: #B6D0E1\n"
"}"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(70, 140, 261, 31));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Segoe UI")});
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setStrikeOut(false);
        font2.setKerning(true);
        font2.setStyleStrategy(QFont::PreferDefault);
        label_4->setFont(font2);
        label_4->setTabletTracking(false);
        label_4->setStyleSheet(QString::fromUtf8("letter-spacing: -1px;\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 25px;\n"
"line-height: 38px;\n"
"text-align: center;\n"
"color: #1A4568;\n"
"qproperty-alignment: 'AlignCenter';\n"
""));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(110, 50, 191, 22));
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	qproperty-alignment: 'AlignCenter';\n"
"	background-color: transparent;\n"
"	color: #B6D0E1\n"
"}"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(100, 20, 211, 31));
        label_6->setFont(font2);
        label_6->setTabletTracking(false);
        label_6->setStyleSheet(QString::fromUtf8("letter-spacing: -1px;\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 25px;\n"
"line-height: 38px;\n"
"text-align: center;\n"
"color: #1A4568;\n"
"background-color: transparent;\n"
"qproperty-alignment: 'AlignCenter';"));
        frame_4 = new QFrame(centralwidget);
        frame_4->setObjectName("frame_4");
        frame_4->setGeometry(QRect(120, 80, 171, 171));
        frame_4->setStyleSheet(QString::fromUtf8("image: url(:/Dis_pic.png);\n"
"background-color: transparent;"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        pushButton_31 = new QPushButton(centralwidget);
        pushButton_31->setObjectName("pushButton_31");
        pushButton_31->setGeometry(QRect(720, 410, 93, 29));
        pushButton_31->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 41px;\n"
"letter-spacing: -1px;\n"
"background-color: rgb(26, 69, 104);\n"
"color: #FFFFFF;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"color: #808080;\n"
"background-color: rgb(255, 255, 255);\n"
"}\n"
""));
        frame_7 = new QFrame(centralwidget);
        frame_7->setObjectName("frame_7");
        frame_7->setGeometry(QRect(410, 100, 421, 261));
        frame_7->setAutoFillBackground(false);
        frame_7->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);border-radius: 25px;;"));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        pushButton_32 = new QPushButton(frame_7);
        pushButton_32->setObjectName("pushButton_32");
        pushButton_32->setGeometry(QRect(30, 60, 121, 29));
        pushButton_32->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_33 = new QPushButton(frame_7);
        pushButton_33->setObjectName("pushButton_33");
        pushButton_33->setGeometry(QRect(30, 90, 93, 29));
        pushButton_33->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_34 = new QPushButton(frame_7);
        pushButton_34->setObjectName("pushButton_34");
        pushButton_34->setGeometry(QRect(30, 120, 93, 29));
        pushButton_34->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        label_12 = new QLabel(frame_7);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(30, 10, 81, 31));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Segoe UI")});
        font3.setBold(true);
        font3.setItalic(false);
        label_12->setFont(font3);
        label_12->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_35 = new QPushButton(frame_7);
        pushButton_35->setObjectName("pushButton_35");
        pushButton_35->setGeometry(QRect(30, 150, 93, 29));
        pushButton_35->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_36 = new QPushButton(frame_7);
        pushButton_36->setObjectName("pushButton_36");
        pushButton_36->setGeometry(QRect(30, 180, 121, 29));
        pushButton_36->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_37 = new QPushButton(frame_7);
        pushButton_37->setObjectName("pushButton_37");
        pushButton_37->setGeometry(QRect(30, 210, 93, 29));
        pushButton_37->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_38 = new QPushButton(frame_7);
        pushButton_38->setObjectName("pushButton_38");
        pushButton_38->setGeometry(QRect(220, 60, 121, 29));
        pushButton_38->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_39 = new QPushButton(frame_7);
        pushButton_39->setObjectName("pushButton_39");
        pushButton_39->setGeometry(QRect(220, 90, 171, 29));
        pushButton_39->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_40 = new QPushButton(frame_7);
        pushButton_40->setObjectName("pushButton_40");
        pushButton_40->setGeometry(QRect(220, 120, 161, 29));
        pushButton_40->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_41 = new QPushButton(frame_7);
        pushButton_41->setObjectName("pushButton_41");
        pushButton_41->setGeometry(QRect(220, 150, 161, 29));
        pushButton_41->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_42 = new QPushButton(frame_7);
        pushButton_42->setObjectName("pushButton_42");
        pushButton_42->setGeometry(QRect(220, 180, 161, 29));
        pushButton_42->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_43 = new QPushButton(frame_7);
        pushButton_43->setObjectName("pushButton_43");
        pushButton_43->setGeometry(QRect(220, 210, 161, 29));
        pushButton_43->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        frame_8 = new QFrame(centralwidget);
        frame_8->setObjectName("frame_8");
        frame_8->setGeometry(QRect(0, 90, 401, 341));
        frame_8->setStyleSheet(QString::fromUtf8("background-color: transparent;"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        frame_6 = new QFrame(frame_8);
        frame_6->setObjectName("frame_6");
        frame_6->setGeometry(QRect(220, 60, 151, 261));
        frame_6->setAutoFillBackground(false);
        frame_6->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);border-radius: 25px;;"));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        label_11 = new QLabel(frame_6);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(30, 10, 81, 31));
        label_11->setFont(font3);
        label_11->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_28 = new QPushButton(frame_6);
        pushButton_28->setObjectName("pushButton_28");
        pushButton_28->setGeometry(QRect(30, 60, 93, 29));
        pushButton_28->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_29 = new QPushButton(frame_6);
        pushButton_29->setObjectName("pushButton_29");
        pushButton_29->setGeometry(QRect(30, 90, 93, 29));
        pushButton_29->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        frame_5 = new QFrame(frame_8);
        frame_5->setObjectName("frame_5");
        frame_5->setGeometry(QRect(20, 60, 151, 261));
        frame_5->setAutoFillBackground(false);
        frame_5->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);\n"
"border-radius: 25px;;"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        label_10 = new QLabel(frame_5);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(30, 10, 101, 31));
        label_10->setFont(font3);
        label_10->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_14 = new QPushButton(frame_5);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(30, 60, 93, 29));
        pushButton_14->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
"\n"
""));
        pushButton_27 = new QPushButton(frame_5);
        pushButton_27->setObjectName("pushButton_27");
        pushButton_27->setGeometry(QRect(30, 90, 93, 29));
        pushButton_27->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        frame_9 = new QFrame(centralwidget);
        frame_9->setObjectName("frame_9");
        frame_9->setGeometry(QRect(10, 510, 381, 271));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        pushButton_8 = new QPushButton(frame_9);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(280, 20, 28, 28));
        pushButton_8->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-list.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_8->setIconSize(QSize(28, 28));
        pushButton_4 = new QPushButton(frame_9);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(54, 20, 28, 28));
        pushButton_4->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-icon-Vector.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_4->setIconSize(QSize(28, 28));
        pushButton_3 = new QPushButton(frame_9);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(130, 20, 28, 28));
        pushButton_3->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-icon-file-import.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_3->setIconSize(QSize(28, 28));
        horizontalSlider = new QSlider(frame_9);
        horizontalSlider->setObjectName("horizontalSlider");
        horizontalSlider->setGeometry(QRect(10, 81, 353, 22));
        horizontalSlider->setOrientation(Qt::Horizontal);
        Shuffle_btn = new QPushButton(frame_9);
        Shuffle_btn->setObjectName("Shuffle_btn");
        Shuffle_btn->setGeometry(QRect(206, 20, 28, 28));
        Shuffle_btn->setCursor(QCursor(Qt::PointingHandCursor));
        Shuffle_btn->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-icon-shuffle.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        Shuffle_btn->setIconSize(QSize(28, 28));
        frame_3 = new QFrame(frame_9);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(320, 210, 31, 31));
        frame_3->setStyleSheet(QString::fromUtf8("QFrame {\n"
"	\n"
"	background-image: url(:/volume-high-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        pushButton_6 = new QPushButton(frame_9);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(176, 130, 30, 30));
        pushButton_6->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-play-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_6->setIconSize(QSize(28, 28));
        pushButton_5 = new QPushButton(frame_9);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(100, 130, 30, 30));
        pushButton_5->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-backward-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_5->setIconSize(QSize(28, 28));
        horizontalSlider_2 = new QSlider(frame_9);
        horizontalSlider_2->setObjectName("horizontalSlider_2");
        horizontalSlider_2->setGeometry(QRect(50, 215, 261, 22));
        horizontalSlider_2->setMaximum(100);
        horizontalSlider_2->setSingleStep(1);
        horizontalSlider_2->setValue(100);
        horizontalSlider_2->setSliderPosition(100);
        horizontalSlider_2->setOrientation(Qt::Horizontal);
        frame_2 = new QFrame(frame_9);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(10, 210, 31, 31));
        frame_2->setStyleSheet(QString::fromUtf8("QFrame {\n"
"	background-image: url(:/voulume-off-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        pushButton_7 = new QPushButton(frame_9);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(252, 130, 30, 30));
        pushButton_7->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-image: url(:/button-forward-solid.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"	border: none;\n"
"}"));
        pushButton_7->setIconSize(QSize(28, 28));
        current_time = new QLabel(frame_9);
        current_time->setObjectName("current_time");
        current_time->setGeometry(QRect(10, 100, 101, 16));
        QFont font4;
        font4.setPointSize(10);
        font4.setBold(true);
        current_time->setFont(font4);
        current_time->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	color: #FFFFFF;\n"
"}"));
        total_time = new QLabel(frame_9);
        total_time->setObjectName("total_time");
        total_time->setGeometry(QRect(268, 100, 101, 20));
        total_time->setFont(font4);
        total_time->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	qproperty-alignment: 'AlignRight';\n"
"	color: #FFFFFF;\n"
"}"));
        label_13 = new QLabel(centralwidget);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(10, 10, 251, 51));
        label_13->setFont(font3);
        label_13->setStyleSheet(QString::fromUtf8("font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 27px;\n"
"line-height: 41px;\n"
"letter-spacing: -1px;\n"
"\n"
"color: #1A4568;"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(20, 260, 361, 251));
        listWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(182, 208, 225);"));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "DISCOVER \n"
"YOUR FEEL'N", nullptr));
        pushButton->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "is playing right now", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "DISCOVER", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "is playing right now", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "DISCOVER", nullptr));
        pushButton_31->setText(QCoreApplication::translate("MainWindow", "APPLY", nullptr));
        pushButton_32->setText(QCoreApplication::translate("MainWindow", "PLAY/PAUSE", nullptr));
        pushButton_33->setText(QCoreApplication::translate("MainWindow", "NEXT", nullptr));
        pushButton_34->setText(QCoreApplication::translate("MainWindow", "PREVIOUS", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "HOTKEYS", nullptr));
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "SETTINGS", nullptr));
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "IMPORT FILE", nullptr));
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "SHUFFLE", nullptr));
        pushButton_38->setText(QCoreApplication::translate("MainWindow", "SPACEBAR", nullptr));
        pushButton_39->setText(QCoreApplication::translate("MainWindow", "RIGHTARROWKEY", nullptr));
        pushButton_40->setText(QCoreApplication::translate("MainWindow", "LEFTARROWKEY", nullptr));
        pushButton_41->setText(QCoreApplication::translate("MainWindow", "ESC", nullptr));
        pushButton_42->setText(QCoreApplication::translate("MainWindow", "CTRL + O", nullptr));
        pushButton_43->setText(QCoreApplication::translate("MainWindow", "S", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Theme", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "LIGHTBLUE", nullptr));
        pushButton_29->setText(QCoreApplication::translate("MainWindow", "TOKYO", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Language", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "ENGLISH", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "\340\271\204\340\270\227\340\270\242", nullptr));
        pushButton_8->setText(QString());
        pushButton_4->setText(QString());
        pushButton_3->setText(QString());
        Shuffle_btn->setText(QString());
        pushButton_6->setText(QString());
        pushButton_5->setText(QString());
        pushButton_7->setText(QString());
        current_time->setText(QCoreApplication::translate("MainWindow", "00:00", nullptr));
        total_time->setText(QCoreApplication::translate("MainWindow", "00:00", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "SETTINGS", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
