/********************************************************************************
** Form generated from reading UI file 'eq.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EQ_H
#define UI_EQ_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EQ
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QFrame *frame_2;
    QLabel *label_7;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_7;
    QFrame *frame_3;
    QLabel *label_8;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QFrame *frame_4;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QLabel *label_9;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QPushButton *pushButton_21;
    QPushButton *pushButton_22;
    QLabel *label_2;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *EQ)
    {
        if (EQ->objectName().isEmpty())
            EQ->setObjectName("EQ");
        EQ->resize(900, 500);
        EQ->setMinimumSize(QSize(900, 500));
        EQ->setMaximumSize(QSize(900, 500));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Dis_pic.png"), QSize(), QIcon::Normal, QIcon::Off);
        EQ->setWindowIcon(icon);
        EQ->setAutoFillBackground(false);
        EQ->setStyleSheet(QString::fromUtf8("background-color: rgb(144,175,196);"));
        centralwidget = new QWidget(EQ);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(30, 20, 381, 51));
        QFont font;
        font.setFamilies({QString::fromUtf8("Segoe UI")});
        font.setBold(true);
        font.setItalic(false);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 27px;\n"
"line-height: 41px;\n"
"letter-spacing: -1px;\n"
"\n"
"color: #1A4568;"));
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(30, 120, 151, 261));
        frame_2->setAutoFillBackground(false);
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);border-radius: 25px;;"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        label_7 = new QLabel(frame_2);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(30, 10, 101, 31));
        label_7->setFont(font);
        label_7->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_2 = new QPushButton(frame_2);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(30, 60, 93, 29));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
"\n"
""));
        pushButton_3 = new QPushButton(frame_2);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(30, 90, 93, 29));
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(750, 430, 93, 29));
        pushButton_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 41px;\n"
"letter-spacing: -1px;\n"
"background-color: rgb(26, 69, 104);\n"
"color: #FFFFFF;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"color: #808080;\n"
"background-color: rgb(255, 255, 255);\n"
"}\n"
""));
        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(230, 120, 151, 261));
        frame_3->setAutoFillBackground(false);
        frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);border-radius: 25px;;"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label_8 = new QLabel(frame_3);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(30, 10, 81, 31));
        label_8->setFont(font);
        label_8->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_8 = new QPushButton(frame_3);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(30, 60, 93, 29));
        pushButton_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_9 = new QPushButton(frame_3);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(30, 90, 93, 29));
        pushButton_9->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_10 = new QPushButton(frame_3);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(30, 120, 93, 29));
        pushButton_10->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        frame_4 = new QFrame(centralwidget);
        frame_4->setObjectName("frame_4");
        frame_4->setGeometry(QRect(440, 120, 421, 261));
        frame_4->setAutoFillBackground(false);
        frame_4->setStyleSheet(QString::fromUtf8("background-color: rgb(26, 69, 104);border-radius: 25px;;"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        pushButton_11 = new QPushButton(frame_4);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(30, 60, 121, 29));
        pushButton_11->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_12 = new QPushButton(frame_4);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(30, 90, 93, 29));
        pushButton_12->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_13 = new QPushButton(frame_4);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(30, 120, 93, 29));
        pushButton_13->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        label_9 = new QLabel(frame_4);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(30, 10, 81, 31));
        label_9->setFont(font);
        label_9->setStyleSheet(QString::fromUtf8("font-weight: 2000;\n"
"font-size: 20px;\n"
"line-height: 24px;\n"
"text-align: center;\n"
"color: #FFFFFF;"));
        pushButton_14 = new QPushButton(frame_4);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(30, 150, 93, 29));
        pushButton_14->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_15 = new QPushButton(frame_4);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(30, 180, 121, 29));
        pushButton_15->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_16 = new QPushButton(frame_4);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(30, 210, 93, 29));
        pushButton_16->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_17 = new QPushButton(frame_4);
        pushButton_17->setObjectName("pushButton_17");
        pushButton_17->setGeometry(QRect(220, 60, 121, 29));
        pushButton_17->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_18 = new QPushButton(frame_4);
        pushButton_18->setObjectName("pushButton_18");
        pushButton_18->setGeometry(QRect(220, 90, 171, 29));
        pushButton_18->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_19 = new QPushButton(frame_4);
        pushButton_19->setObjectName("pushButton_19");
        pushButton_19->setGeometry(QRect(220, 120, 161, 29));
        pushButton_19->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_20 = new QPushButton(frame_4);
        pushButton_20->setObjectName("pushButton_20");
        pushButton_20->setGeometry(QRect(220, 150, 161, 29));
        pushButton_20->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_21 = new QPushButton(frame_4);
        pushButton_21->setObjectName("pushButton_21");
        pushButton_21->setGeometry(QRect(220, 180, 161, 29));
        pushButton_21->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        pushButton_22 = new QPushButton(frame_4);
        pushButton_22->setObjectName("pushButton_22");
        pushButton_22->setGeometry(QRect(220, 210, 161, 29));
        pushButton_22->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 16px;\n"
"line-height: 24px;\n"
"text-align: left;\n"
"color: #5F84A1;\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(158, 170, 189)\n"
"}\n"
""));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 20, 381, 51));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("font-style: normal;\n"
"font-weight: 2000;\n"
"font-size: 27px;\n"
"line-height: 41px;\n"
"letter-spacing: -1px;\n"
"\n"
"color: #1A4568;"));
        EQ->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(EQ);
        statusbar->setObjectName("statusbar");
        EQ->setStatusBar(statusbar);

        retranslateUi(EQ);

        QMetaObject::connectSlotsByName(EQ);
    } // setupUi

    void retranslateUi(QMainWindow *EQ)
    {
        EQ->setWindowTitle(QCoreApplication::translate("EQ", "Equalizer", nullptr));
        label->setText(QCoreApplication::translate("EQ", "SETTINGS", nullptr));
        label_7->setText(QCoreApplication::translate("EQ", "Language", nullptr));
        pushButton_2->setText(QCoreApplication::translate("EQ", "ENGLISH", nullptr));
        pushButton_3->setText(QCoreApplication::translate("EQ", "THAI", nullptr));
        pushButton_7->setText(QCoreApplication::translate("EQ", "APPLY", nullptr));
        label_8->setText(QCoreApplication::translate("EQ", "Theme", nullptr));
        pushButton_8->setText(QCoreApplication::translate("EQ", "LIGHT", nullptr));
        pushButton_9->setText(QCoreApplication::translate("EQ", "DARK", nullptr));
        pushButton_10->setText(QCoreApplication::translate("EQ", "CUSTOM", nullptr));
        pushButton_11->setText(QCoreApplication::translate("EQ", "PLAY/PAUSE", nullptr));
        pushButton_12->setText(QCoreApplication::translate("EQ", "NEXT", nullptr));
        pushButton_13->setText(QCoreApplication::translate("EQ", "PREVIOUS", nullptr));
        label_9->setText(QCoreApplication::translate("EQ", "HOTKEYS", nullptr));
        pushButton_14->setText(QCoreApplication::translate("EQ", "SETTINGS", nullptr));
        pushButton_15->setText(QCoreApplication::translate("EQ", "IMPORT FILE", nullptr));
        pushButton_16->setText(QCoreApplication::translate("EQ", "SHUFFLE", nullptr));
        pushButton_17->setText(QCoreApplication::translate("EQ", "SPACEBAR", nullptr));
        pushButton_18->setText(QCoreApplication::translate("EQ", "RIGHTARROWKEY", nullptr));
        pushButton_19->setText(QCoreApplication::translate("EQ", "LEFTARROWKEY", nullptr));
        pushButton_20->setText(QCoreApplication::translate("EQ", "ESC", nullptr));
        pushButton_21->setText(QCoreApplication::translate("EQ", "CTRL + O", nullptr));
        pushButton_22->setText(QCoreApplication::translate("EQ", "S", nullptr));
        label_2->setText(QCoreApplication::translate("EQ", "\340\270\227\340\270\224\340\270\252\340\270\255\340\270\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EQ: public Ui_EQ {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EQ_H
