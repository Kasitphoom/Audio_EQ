/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Audio_pj/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[72];
    char stringdata0[11];
    char stringdata1[22];
    char stringdata2[1];
    char stringdata3[4];
    char stringdata4[6];
    char stringdata5[5];
    char stringdata6[5];
    char stringdata7[5];
    char stringdata8[5];
    char stringdata9[24];
    char stringdata10[9];
    char stringdata11[12];
    char stringdata12[25];
    char stringdata13[25];
    char stringdata14[6];
    char stringdata15[10];
    char stringdata16[25];
    char stringdata17[25];
    char stringdata18[35];
    char stringdata19[24];
    char stringdata20[16];
    char stringdata21[24];
    char stringdata22[10];
    char stringdata23[16];
    char stringdata24[9];
    char stringdata25[16];
    char stringdata26[4];
    char stringdata27[33];
    char stringdata28[34];
    char stringdata29[35];
    char stringdata30[24];
    char stringdata31[23];
    char stringdata32[16];
    char stringdata33[26];
    char stringdata34[17];
    char stringdata35[5];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 3),  // "map"
        QT_MOC_LITERAL(38, 5),  // "value"
        QT_MOC_LITERAL(44, 4),  // "min1"
        QT_MOC_LITERAL(49, 4),  // "max1"
        QT_MOC_LITERAL(54, 4),  // "min2"
        QT_MOC_LITERAL(59, 4),  // "max2"
        QT_MOC_LITERAL(64, 23),  // "on_pushButton_8_clicked"
        QT_MOC_LITERAL(88, 8),  // "showMain"
        QT_MOC_LITERAL(97, 11),  // "showSetting"
        QT_MOC_LITERAL(109, 24),  // "on_pushButton_27_clicked"
        QT_MOC_LITERAL(134, 24),  // "on_pushButton_14_clicked"
        QT_MOC_LITERAL(159, 5),  // "Tokyo"
        QT_MOC_LITERAL(165, 9),  // "Lightblue"
        QT_MOC_LITERAL(175, 24),  // "on_pushButton_29_clicked"
        QT_MOC_LITERAL(200, 24),  // "on_pushButton_28_clicked"
        QT_MOC_LITERAL(225, 34),  // "on_horizontalSlider_2_valueCh..."
        QT_MOC_LITERAL(260, 23),  // "on_pushButton_6_clicked"
        QT_MOC_LITERAL(284, 15),  // "update_filename"
        QT_MOC_LITERAL(300, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(324, 9),  // "setSource"
        QT_MOC_LITERAL(334, 15),  // "durationChanged"
        QT_MOC_LITERAL(350, 8),  // "duration"
        QT_MOC_LITERAL(359, 15),  // "positionChanged"
        QT_MOC_LITERAL(375, 3),  // "pos"
        QT_MOC_LITERAL(379, 32),  // "on_horizontalSlider_valueChanged"
        QT_MOC_LITERAL(412, 33),  // "on_horizontalSlider_sliderPre..."
        QT_MOC_LITERAL(446, 34),  // "on_horizontalSlider_sliderRel..."
        QT_MOC_LITERAL(481, 23),  // "on_pushButton_5_clicked"
        QT_MOC_LITERAL(505, 22),  // "on_Shuffle_btn_clicked"
        QT_MOC_LITERAL(528, 15),  // "update_playlist"
        QT_MOC_LITERAL(544, 25),  // "on_listWidget_itemPressed"
        QT_MOC_LITERAL(570, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(587, 4)   // "item"
    },
    "MainWindow",
    "on_pushButton_clicked",
    "",
    "map",
    "value",
    "min1",
    "max1",
    "min2",
    "max2",
    "on_pushButton_8_clicked",
    "showMain",
    "showSetting",
    "on_pushButton_27_clicked",
    "on_pushButton_14_clicked",
    "Tokyo",
    "Lightblue",
    "on_pushButton_29_clicked",
    "on_pushButton_28_clicked",
    "on_horizontalSlider_2_valueChanged",
    "on_pushButton_6_clicked",
    "update_filename",
    "on_pushButton_7_clicked",
    "setSource",
    "durationChanged",
    "duration",
    "positionChanged",
    "pos",
    "on_horizontalSlider_valueChanged",
    "on_horizontalSlider_sliderPressed",
    "on_horizontalSlider_sliderReleased",
    "on_pushButton_5_clicked",
    "on_Shuffle_btn_clicked",
    "update_playlist",
    "on_listWidget_itemPressed",
    "QListWidgetItem*",
    "item"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  164,    2, 0x08,    1 /* Private */,
       3,    5,  165,    2, 0x08,    2 /* Private */,
       9,    0,  176,    2, 0x08,    8 /* Private */,
      10,    0,  177,    2, 0x08,    9 /* Private */,
      11,    0,  178,    2, 0x08,   10 /* Private */,
      12,    0,  179,    2, 0x08,   11 /* Private */,
      13,    0,  180,    2, 0x08,   12 /* Private */,
      14,    0,  181,    2, 0x08,   13 /* Private */,
      15,    0,  182,    2, 0x08,   14 /* Private */,
      16,    0,  183,    2, 0x08,   15 /* Private */,
      17,    0,  184,    2, 0x08,   16 /* Private */,
      18,    1,  185,    2, 0x08,   17 /* Private */,
      19,    0,  188,    2, 0x08,   19 /* Private */,
      20,    0,  189,    2, 0x08,   20 /* Private */,
      21,    0,  190,    2, 0x08,   21 /* Private */,
      22,    0,  191,    2, 0x08,   22 /* Private */,
      23,    1,  192,    2, 0x08,   23 /* Private */,
      25,    1,  195,    2, 0x08,   25 /* Private */,
      27,    1,  198,    2, 0x08,   27 /* Private */,
      28,    0,  201,    2, 0x08,   29 /* Private */,
      29,    0,  202,    2, 0x08,   30 /* Private */,
      30,    0,  203,    2, 0x08,   31 /* Private */,
      31,    0,  204,    2, 0x08,   32 /* Private */,
      32,    0,  205,    2, 0x08,   33 /* Private */,
      33,    1,  206,    2, 0x08,   34 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,    4,    5,    6,    7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong,   24,
    QMetaType::Void, QMetaType::LongLong,   26,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 34,   35,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'map'
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'on_pushButton_8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showMain'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showSetting'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_27_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_14_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'Tokyo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'Lightblue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_29_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_28_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_horizontalSlider_2_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_filename'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setSource'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'durationChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qint64, std::false_type>,
        // method 'positionChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qint64, std::false_type>,
        // method 'on_horizontalSlider_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_horizontalSlider_sliderPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_horizontalSlider_sliderReleased'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Shuffle_btn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_playlist'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_listWidget_itemPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: { double _r = _t->map((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[5])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 2: _t->on_pushButton_8_clicked(); break;
        case 3: _t->showMain(); break;
        case 4: _t->showSetting(); break;
        case 5: _t->on_pushButton_27_clicked(); break;
        case 6: _t->on_pushButton_14_clicked(); break;
        case 7: _t->Tokyo(); break;
        case 8: _t->Lightblue(); break;
        case 9: _t->on_pushButton_29_clicked(); break;
        case 10: _t->on_pushButton_28_clicked(); break;
        case 11: _t->on_horizontalSlider_2_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->on_pushButton_6_clicked(); break;
        case 13: _t->update_filename(); break;
        case 14: _t->on_pushButton_7_clicked(); break;
        case 15: _t->setSource(); break;
        case 16: _t->durationChanged((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 17: _t->positionChanged((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 18: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->on_horizontalSlider_sliderPressed(); break;
        case 20: _t->on_horizontalSlider_sliderReleased(); break;
        case 21: _t->on_pushButton_5_clicked(); break;
        case 22: _t->on_Shuffle_btn_clicked(); break;
        case 23: _t->update_playlist(); break;
        case 24: _t->on_listWidget_itemPressed((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 25;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
